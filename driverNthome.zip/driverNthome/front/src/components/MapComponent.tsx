import React, { useEffect, useRef, useState } from 'react';
import { View, StyleSheet, Image, Text,Animated, Easing  } from 'react-native';
import MapView, { PROVIDER_GOOGLE, Marker } from 'react-native-maps';
import MapViewDirections from 'react-native-maps-directions';
import { mapStyle } from '../global/mapStyle';
import { colors } from '../global/styles';
import { GOOGLE_MAPS_APIKEY } from "@env";

const MapComponent = ({ userOrigin, userDestination, driverLocation }) => {
    const mapRef = useRef(null);
    const [mapBearing, setMapBearing] = useState(0); // Add state for map bearing
    const [instructions, setInstructions] = useState([]);
    const [currentStep, setCurrentStep] = useState(0);
    const [distance, setDistance] = useState(null);
    const [duration, setDuration] = useState(null);
    const rotateAnimatedValue = useRef(new Animated.Value(0)).current;
    useEffect(() => {
        if (userOrigin?.latitude && userDestination?.latitude && driverLocation?.latitude) {
            const coordinates = [userOrigin, userDestination, driverLocation].filter(
                (coord) => coord?.latitude && coord?.longitude
            );
            if (coordinates.length > 0 && mapRef.current) {
                mapRef.current.fitToCoordinates(coordinates, {
                    edgePadding: {
                        top: 50,
                        right: 50,
                        left: 50,
                        bottom: 50,
                    },
                    animated: true,
                });
            }
        }
    }, [userOrigin, userDestination, driverLocation]);

    useEffect(() => {
        if (driverLocation?.latitude && driverLocation?.longitude && mapRef.current) {
            mapRef.current.animateToRegion({
                latitude: driverLocation.latitude,
                longitude: driverLocation.longitude,
                latitudeDelta: 0.005,
                longitudeDelta: 0.005,
            });
        }
    }, [driverLocation]);

    const handleDirectionsReady = (result) => {
        if (result.distance > 0 && result.duration > 0) {
            setDistance(result.distance.toFixed(2)); // Round to 2 decimal places
            setDuration(result.duration.toFixed(2));
        }
        setInstructions(result.legs[0].steps);
        console.log('Distance:', result.distance);
        console.log('Duration:', result.duration);
    };

    const initialRegion = driverLocation?.latitude && driverLocation?.longitude
        ? {
            latitude: driverLocation.latitude,
            longitude: driverLocation.longitude,
            latitudeDelta: 0.005,
            longitudeDelta: 0.005,
        }
        : {
            latitude: -25.5399,
            longitude: 28.1000,
            latitudeDelta: 0.005,
            longitudeDelta: 0.005,
        };

    return (
        <View style={styles.container}>
            <MapView
                provider={PROVIDER_GOOGLE}
                style={styles.map}
                ref={mapRef}
                initialRegion={initialRegion}
                showsUserLocation={true}
                followsUserLocation={true}
            >
         {driverLocation?.latitude && driverLocation?.longitude && (
                    <Marker
                        coordinate={driverLocation}
                        anchor={{ x: 0.5, y: 0.5 }}
                        rotation={mapBearing} // Pass the map bearing to the Marker
                    >
                        <Animated.View style={[
                            {
                                width: 33,
                                height: 33,
                                justifyContent: 'center',
                                alignItems: 'center',
                                borderRadius: 20,
                                backgroundColor: 'rgba(0, 0, 255, 0.2)',
                                shadowColor: '#0000ff',
                                shadowOffset: { width: 0, height: 0 },
                                shadowOpacity: 0.8,
                                elevation: 5,
                                transform: [{
                                    rotate: rotateAnimatedValue.interpolate({
                                        inputRange: [0, 360],
                                        outputRange: ['0deg', '360deg'],
                                    })
                                }]
                            }
                        ]}>
                            <Image
                                source={require('../../assets/carM.png')}
                                style={{
                                    width: 35,
                                    height: 35,
                                }}
                                resizeMode="contain"
                            />
                        </Animated.View>
                    </Marker>
                )}
                {userOrigin?.latitude && userOrigin?.longitude && (
                    <Marker coordinate={userOrigin}>
                        <Image
                            source={{ uri: "https://maps.google.com/mapfiles/kml/paddle/grn-circle.png" }}
                            style={styles.markerOrigin}
                            resizeMode="cover"
                        />
                    </Marker>
                )}

                {/* Directions from Driver Location to User Pickup */}
                {driverLocation?.latitude && userOrigin?.latitude && (
                    <MapViewDirections
                        origin={driverLocation}
                        destination={userOrigin}
                        apikey={GOOGLE_MAPS_APIKEY}
                        strokeWidth={4}
                        strokeColor="blue"
                        onReady={handleDirectionsReady}
                        onError={(error) => console.error("Directions Error:", error)}
                    />
                )}
            </MapView>

            {/* Show Distance & Duration at the Top Center */}
            {distance && duration && (
                <View style={styles.infoContainer}>
                    <Text style={styles.infoText}>Distance: {distance} km</Text>
                    <Text style={styles.infoText}>ETA: {duration} mins</Text>
                </View>
            )}

            <View style={styles.instructionsContainer}>
                {instructions.length > 0 && currentStep < instructions.length ? (
                    <Text style={styles.instructionText}>
                        {instructions[currentStep].html_instructions.replace(/<[^>]+>/g, '')}
                    </Text>
                ) : (
                    <Text style={styles.instructionText}>Arrived at your destination!</Text>
                )}
            </View>
        </View>
    );
};

export default MapComponent;
const styles = StyleSheet.create({
    map: {
        height: "100%",
        width: "100%"
    },


    markerWrapOrigin: {
        //  alignItems: "center",
        // justifyContent: "center",
        width: 40,
        height: 20,
        // marginTop:0
    },
    markerOrigin: {
        width: 30,
        height: 35,
        borderRadius: 15
    },

    destination: {
        width: 20,
        height: 20,
        backgroundColor: colors.black,
        alignItems: "center",
        justifyContent: "center"
    },

    view1: {
        width: 7,
        height: 7,
        backgroundColor: colors.white
    },
    markerDestination: {
        width: 16,
        height: 16,

    },

    markerOrigin2: {
        width: 20,
        height: 20,
        borderRadius: 10
    },
    markerDriver: {
        width: 40,
        height: 20,
    },
    car: {
        paddingTop: 0,
        width: 40,
        height: 20,
    },

    view2: {
        position: "absolute",
        top: 10,
        right: 12,
        backgroundColor: colors.white,
        height: 40,
        width: 180,
        borderRadius: 20,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 2,
        zIndex: 8

    },

    view3: {
        flexDirection: "row",
        alignItems: "center",
        //marginRight:15,
        //backgroundColor:"white",
        //paddingHorizontal:2,
        paddingVertical: 2,
        //borderRadius:20
    },

    view4: {
        position: "absolute",
        top: 50,
        left: 12,
        backgroundColor: colors.white,
        height: 40,
        width: 140,
        borderRadius: 20,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 2,
        zIndex: 8

    },

    location: {
        width: 20,
        height: 20,
        borderRadius: 9,
        backgroundColor: colors.black,
        alignItems: "center",
        justifyContent: "center"

    },

    view9: {
        width: 6,
        height: 6,
        borderRadius: 4,
        backgroundColor: "white"
    },
    instructionsContainer: {
        position: 'absolute',
        bottom: 60,
        left: '5%',
        right: '5%',
        backgroundColor: 'rgba(255, 255, 255, 0.8)',
        borderRadius: 10,
        padding: 15,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.3,
        shadowRadius: 4,
        elevation: 3,
    },
    instructionText: {
        fontSize: 15,
        color: colors.black,
    },
    infoText: {
        color: "white",
        fontSize: 16,
        fontWeight: "bold",
    },
    infoContainer: {
        position: "absolute",
        top: 20,
        left: "25%",
        right: "25%",
        backgroundColor: "rgba(0, 0, 0, 0.7)",
        padding: 10,
        borderRadius: 10,
        alignItems: "center",
    },
})