// redux/actions/authActions.js
export const setUser = (user) => ({
    type: 'SET_USER',
    payload: user,
  });
  