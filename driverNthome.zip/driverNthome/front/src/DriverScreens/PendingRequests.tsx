import React, { useContext, useState, useEffect } from 'react';
import { StyleSheet, View, Dimensions, TouchableOpacity, Image, Text, Animated } from 'react-native';
import { Icon } from 'react-native-elements';
import { colors } from '../global/styles';
import { DestinationContext, OriginContext } from '../contexts/contexts';
import MapComponent from '../components/MapComponent';
import * as Location from 'expo-location';
import { SafeAreaView } from 'react-native-safe-area-context';
import { db } from '../../FirebaseConfig';
import { collection, query, where, onSnapshot, doc, setDoc } from 'firebase/firestore';
import { useSelector } from 'react-redux';

const SCREEN_HEIGHT = Dimensions.get('window').height;
const SCREEN_WIDTH = Dimensions.get('window').width;

export default function PendingRequests({ navigation, route }) {
  const user = useSelector((state) => state.auth.user);
  const user_id = user.user_id; 

  const tripAccepted = route.params?.tripAccepted;
  const tripData = route.params?.tripData;

  console.log("Driver ID:", user_id, "Trip Data:", tripData);

  // Extracting user origin and destination from tripData
  const [userOrigin, setUserOrigin] = useState({
    latitude: tripData?.pickUpCoordinates?.latitude ?? 0,
    longitude: tripData?.pickUpCoordinates?.longitude ?? 0,
  });

  const [userDestination, setUserDestination] = useState({
    latitude: tripData?.dropOffCoordinates?.latitude ?? 0,
    longitude: tripData?.dropOffCoordinates?.longitude ?? 0,
  });

  // Update state when tripData changes
  useEffect(() => {
    if (tripData?.pickUpCoordinates) {
      setUserOrigin({
        latitude: tripData.pickUpCoordinates.latitude,
        longitude: tripData.pickUpCoordinates.longitude,
      });
    }

    if (tripData?.dropOffCoordinates) {
      setUserDestination({
        latitude: tripData.dropOffCoordinates.latitude,
        longitude: tripData.dropOffCoordinates.longitude,
      });
    }
  }, [tripData]);

  const [driverLocation, setDriverLocation] = useState({
    latitude: 0,
    longitude: 0,
  });

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.error('Permission to access location was denied');
        return;
      }

      const watchId = Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          timeInterval: 20000,
          distanceInterval: 1,
        },
        async (position) => {
          const { latitude, longitude } = position.coords;
          setDriverLocation({ latitude, longitude });

          try {
            const driverLocationRef = doc(db, 'driver_locations', user_id.toString());
            await setDoc(driverLocationRef, {
              userId: user_id,
              latitude,
              longitude,
              timestamp: new Date().toISOString(),
            }, { merge: true });

            console.log('Driver location saved successfully!');
          } catch (error) {
            console.error('Error saving driver location:', error);
          }
        }
      );

      return () => {
        watchId.remove();
      };
    })();
  }, [user_id]);

  const [animationValue] = useState(new Animated.Value(1));
  const [isOnline, setIsOnline] = useState(false);
  const [bellAnimation] = useState(new Animated.Value(1));
  const [notificationCount, setNotificationCount] = useState(0);

  const animateButton = () => {
    Animated.sequence([
      Animated.timing(animationValue, {
        toValue: 1.2,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(animationValue, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const animateBell = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(bellAnimation, {
          toValue: 1.1,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.timing(bellAnimation, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
      ])
    ).start();
  };

  const handleGoOnline = () => {
    animateButton();
    setIsOnline(!isOnline);
  };

  useEffect(() => {
    animateBell();
  }, []);

  useEffect(() => {
    const driverId = user_id;
    const tripsRef = collection(db, 'trips');
    const q = query(tripsRef, where('driverId', '==', driverId));

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      let count = 0;
      querySnapshot.forEach(() => {
        count++;
      });
      setNotificationCount(count);
    });

    return () => unsubscribe();
  }, []);

  const handleNotificationClick = () => {
    if (notificationCount > 0) {
      setNotificationCount(notificationCount - 1);
    }
    navigation.navigate('PendingTripsBottomSheet', { tripAccepted: true });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.openDrawer()} style={styles.roundButton}>
          <Icon type="material-community" name="menu" color={colors.black} size={30} />
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        style={styles.profilePictureContainer}
        onPress={() => navigation.navigate('CustomerCommunicationBottomSheet')}
      >
        <Image source={require('../../assets/call.png')} style={styles.profilePicture} />
      </TouchableOpacity>

      <MapComponent driverLocation={driverLocation} userOrigin={userOrigin} userDestination={userDestination} />

      <Animated.View style={{ transform: [{ scale: animationValue }] }}>
        <TouchableOpacity style={styles.goOnlineButton} onPress={handleGoOnline}>
          <Text style={styles.goOnlineText}>{isOnline ? 'OFF' : 'GO'}</Text>
        </TouchableOpacity>
      </Animated.View>

      <Animated.View style={[styles.bellContainer, { transform: [{ scale: bellAnimation }] }]}>
        <TouchableOpacity onPress={handleNotificationClick}>
          <Icon name="bell" type="material-community" size={30} color="#007aff" />
          {notificationCount > 0 && (
            <View style={styles.notificationBadge}>
              <Text style={styles.notificationText}>{notificationCount}</Text>
            </View>
          )}
        </TouchableOpacity>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // paddingTop: parameters.statusBarHeight,
    backgroundColor: colors.white,
  },
  view1: {
    position: 'absolute',
    top: 25,
    left: 12,
    backgroundColor: colors.white,
    height: 40,
    width: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 30,
    zIndex: 10,
  },
  profilePictureContainer: {
    position: 'absolute',
    top: 70,
    right: 12,
    backgroundColor: colors.white,
    height: 40,
    width: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 30,
    zIndex: 10,
  },

  profilePicture: {
    height: 40,
    width: 40,
    borderRadius: 20,
  },
  goOnlineButton: {
    position: 'absolute',
    bottom: 130, // Adjust as needed
    left: SCREEN_WIDTH / 2 - 30, // Center the button horizontally
    backgroundColor: '#007aff', // Button color
    borderRadius: 30, // Circular shape
    width: 60, // Diameter
    height: 60, // Diameter
    justifyContent: 'center', // Center text vertically
    alignItems: 'center', // Center text horizontally
    elevation: 5, // Shadow effect for Android
  },
  goOnlineText: {
    color: '#fff', // Text color
    fontSize: 24, // Font size for "GO"
    fontWeight: 'bold', // Bold text
  },
  bellContainer: {
    position: 'absolute',
    top: 160,
    right: 20,
    alignItems: 'center',
  },
  notificationBadge: {
    position: 'absolute',
    right: -10,
    top: -10,
    backgroundColor: 'red',
    borderRadius: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notificationText: {
    color: 'white',
    fontWeight: 'bold',
  },
  header: {
    position: "absolute", // Ensures it floats on top of the screen
    top: 60, // Adjust for slight padding at the top
    left: 10, // Adjust for slight padding at the left
    zIndex: 100, // Ensures it's above other elements
  },
  roundButton: {
    backgroundColor: "#fff", // Add a background color
    borderRadius: 30, // Make it round (half of the width/height)
    width: 50, // Diameter of the circle
    height: 50, // Diameter of the circle
    justifyContent: "center", // Center the icon vertically
    alignItems: "center", // Center the icon horizontally
    shadowColor: "#000", // Add shadow (optional)
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5, // Elevation for Android
  },
});