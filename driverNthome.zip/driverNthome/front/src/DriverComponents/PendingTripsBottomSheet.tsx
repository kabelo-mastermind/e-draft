import { BlurView } from 'expo-blur';
import React, { useState, useEffect } from 'react';
import { Pressable, StyleSheet, FlatList } from 'react-native';
import { View, Text } from 'react-native-animatable';
import TripRequestModal from '../DriverComponents/Modals/TripRequestModal';
import { db } from '../../FirebaseConfig'; // Import firebase config
import { collection, query, where, onSnapshot } from 'firebase/firestore'; // Correct imports for Firestore real-time updates
import { useSelector } from 'react-redux';
import axios from 'axios';

const PendingTripsBottomSheet = ({ navigation, route }) => {
  const [pendingTrips, setPendingTrips] = useState([]); // State to hold pending trips
  const [selectedRequest, setSelectedRequest] = useState(null); // State to hold selected request
  const user = useSelector((state) => state.auth.user);
  const tripAccepted = route.params?.tripAccepted;
  
  const user_id = user.user_id; // Assuming the user object has the driver's ID
  // console.log("pendingTripsrrrrrrrrrrrrr:", pendingTrips); // Log the driver ID for debugging
  const [userData, setUserData] = useState(null); // State to store user details
  
  console.log("userData",userData ); // Log the driver ID for debugging
  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        if (!pendingTrips.length) return; // Ensure there are pending trips before making a request
    
        const customerId = pendingTrips[0].customerId;
    
        console.log("customerid", customerId); // Log the customer ID for debugging
    
        // Pass the customerId in the query string
        const response = await axios.get(`http://10.0.2.2:3000/api/customer?customerId=${customerId}`);
    
        console.log("userdatagggggggggggggg", response.data); // Log the user data for debugging
        setUserData(response.data);
    
    } catch (error) {
        console.error('Error fetching user details:', error.response ? error.response.data : error.message);
    }
    
    };

    fetchUserDetails();
}, [pendingTrips]);

  
  // Fetch pending trips from Firestore based on driverId when the component mounts
  useEffect(() => {
    const fetchPendingTrips = () => {
      try {
        const tripRef = collection(db, 'trips');
        const tripQuery = query(tripRef, where('driverId', '==', user_id));
  
        const unsubscribe = onSnapshot(tripQuery, (querySnapshot) => {
          let tripsList = querySnapshot.docs.map(doc => {
            const tripData = doc.data();
            tripData.id = doc.id;
            return tripData;
          });
  
          // Sort trips by timestamp (assuming `createdAt` is the field storing the timestamp)
          tripsList.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  
          // Remove duplicate trips with the same date and time
          const uniqueTrips = [];
          const seenTimestamps = new Set();
  
          for (let trip of tripsList) {
            const timestamp = trip.createdAt; // Ensure `createdAt` is a valid timestamp
            if (!seenTimestamps.has(timestamp)) {
              seenTimestamps.add(timestamp);
              uniqueTrips.push(trip);
            }
          }
  
          // Set only the latest trip in state
          setPendingTrips(uniqueTrips.length > 0 ? [uniqueTrips[0]] : []);
        });
  
        return unsubscribe;
      } catch (error) {
        console.error('Error fetching pending trips from Firebase:', error);
      }
    };
  
    if (user_id) {
      const unsubscribe = fetchPendingTrips();
      return () => unsubscribe();
    }
  }, [user_id]);
  
  const removeTripFromList = (tripId) => {
    setPendingTrips((prevTrips) => prevTrips.filter(trip => trip.id !== tripId)); // Removes the trip from the list
  };

  const renderRequest = ({ item }) => {
    // console.log(item); // Log the entire item for debugging
    return (
      <View style={styles.itemContainer}>
        <View style={styles.infoContainer}>
          <Text style={styles.passengerName}>Customer: {item.customerId || userData?.name}</Text>
          {/* <Text style={styles.detailText}>Email: {userData?.email || 'N/A'}</Text> */}
          {/* <Text style={styles.detailText}>Phone: {userData?.phoneNumber || 'N/A'}</Text> */}
          <Text style={styles.detailText}>Pickup: {item.pickUpLocation || 'N/A'}</Text>
          <Text style={styles.detailText}>Destination: {item.dropOffLocation || 'N/A'}</Text>
          <Text style={styles.detailText}>Status: {item.statuses || 'Not available'}</Text>
          {/* <Text style={styles.detailText}>Cancellation Reason: {item.cancellation_reason || 'No cancellation'}</Text> */}
        </View>
        <Pressable
          style={styles.actionButton}
          onPress={() => setSelectedRequest(item)} // Set selected item
        >
          <Text style={styles.actionText}>View</Text>
        </Pressable>
      </View>
    );
  };
  

  return (
    <View style={styles.container}>
      <Pressable onPress={() => navigation.goBack()} style={styles.overlay} />
      <BlurView intensity={80} tint="light" style={styles.blurView}>
        <Pressable onPress={() => navigation.goBack()} style={styles.cancelContainer}>
          <Text style={styles.cancelText}>Cancel</Text>
        </Pressable>
        <View style={styles.headerContainer}>
          <Text style={styles.headerText}>Pending Requests</Text>
        </View>
        <FlatList
          data={pendingTrips} // Use fetched pending trips
          keyExtractor={(item) => item.id.toString()} // Ensure keyExtractor works for each item
          renderItem={renderRequest}
          contentContainerStyle={styles.listContent}
        />
      </BlurView>

      {/* Conditionally render TripRequestModal if an item is selected */}
      {selectedRequest && (
        <TripRequestModal
          isVisible={true}
          request={selectedRequest}
          onClose={() => setSelectedRequest(null)} // Close the modal
          onTripUpdate={removeTripFromList} // Pass the function to update the list
        />
      )}
    </View>
  );
};

export default PendingTripsBottomSheet;





const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.1)', // Semi-transparent background for overlay
  },
  overlay: {
    flex: 1,
  },
  blurView: {
    height: '40%',
    width: '100%',
    position: 'absolute',
    bottom: 0,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    overflow: 'hidden',
    padding: 20,
  },
  cancelContainer: {
    alignSelf: 'flex-end',
  },
  cancelText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FF3B30',
  },
  headerContainer: {
    marginTop: 10,
    marginBottom: 20,
    alignItems: 'center',
  },
  headerText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
  },
  listContent: {
    paddingBottom: 20,
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 12,
    marginVertical: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  infoContainer: {
    flex: 1,
  },
  passengerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  detailText: {
    fontSize: 14,
    color: '#6c757d',
  },
  actionButton: {
    backgroundColor: '#007BFF',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 8,
  },
  actionText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#fff',
  },
});
