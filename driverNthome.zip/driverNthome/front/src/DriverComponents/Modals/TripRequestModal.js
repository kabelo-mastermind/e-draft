import React, { useState, useEffect } from 'react';
import { Modal, StyleSheet, View, Text, Pressable, TextInput } from 'react-native';
import { Icon } from 'react-native-elements';
import { io } from 'socket.io-client';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../../FirebaseConfig'; // Adjust the path to where your firebaseConfig is stored
import { useNavigation } from '@react-navigation/native'; // Import the useNavigation hook

const socket = io('http://10.0.2.2:3000'); // Replace with your actual backend URL

const TripRequestModal = ({ isVisible, request, onClose, onTripUpdate }) => {
  const navigation = useNavigation(); // Use the useNavigation hook to access the navigation prop

  if (!isVisible || !request) return null;

  const [cancellationReason, setCancellationReason] = useState('');
  const [cancelBy] = useState('driver'); // assuming the driver is the one canceling the ride

  const passenger = request.customerId || {};
  const pickup = request.pickup || {};
  const destination = request.destination || {};

  const handleAccept = async () => {
    console.log("Accepting trip...");
    try {
      const tripRef = doc(db, "trips", request.id.toString());
      await updateDoc(tripRef, {
        statuses: "accepted",
      });
  
      socket.emit("tripStatusUpdated", { tripId: request.id, status: "accepted" });
      onTripUpdate(request.id, request.driverLocation, request.pickup);
      onClose();
  
      console.log("Navigating to PendingRequests...");
      navigation.navigate("PendingRequests", { tripAccepted: true, tripData: request });
    } catch (error) {
      console.error("Error updating trip status:", error);
    }
  };
  

  const handleDecline = async () => {
    console.log("Accepting trip...");
    try {
      const tripRef = doc(db, "trips", request.id.toString());
      await updateDoc(tripRef, {
        statuses: "decline",
      });
  
      socket.emit("tripStatusUpdated", { tripId: request.id, status: "decline" });
      onTripUpdate(request.id, request.driverLocation, request.pickup);
      onClose();
  
      console.log("Navigating to PendingRequests...");
      navigation.navigate("PendingRequests", { tripAccepted: true, tripData: request });
    } catch (error) {
      console.error("Error updating trip status:", error);
    }
  };

  // Listen for trip status updates
  useEffect(() => {
    socket.on('tripCancelled', (data) => {
      if (data.tripId === request.id) {
        alert('Your ride has been decline!');
      }
    });

    socket.on('tripCancelled', (data) => {
      if (data.tripId === request.id) {
        alert('Your ride has been cancelled!');
      }
    });

    return () => {
      socket.off('tripAccepted');
      socket.off('tripCancelled');
    };
  }, [request]);

  useEffect(() => {
    socket.on('tripStatusUpdated', (data) => {
      if (data.tripId === request.id) {
        alert(`Trip status updated to ${data.status}`);
      }
    });

    return () => {
      socket.off('tripStatusUpdated');
    };
  }, [request]);

  return (
    <Modal animationType="slide" transparent={true} visible={isVisible} onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.modalContainer}>
          <Pressable style={styles.closeButton} onPress={onClose}>
            <Icon name="close" color="#333" size={24} />
          </Pressable>

          <Text style={styles.headerText}>Trip Details for "customerId"={passenger}</Text>

          {/* Display cancellation reason input if declining */}
          <TextInput
            style={styles.textInput}
            placeholder="Enter cancellation reason (optional)"
            value={cancellationReason}
            onChangeText={setCancellationReason}
          />

          <View style={styles.buttonsContainer}>
            <Pressable style={[styles.button, styles.acceptButton]} onPress={handleAccept}>
              <Text style={styles.buttonText}>Accept</Text>
            </Pressable>
            <Pressable style={[styles.button, styles.declineButton]} onPress={handleDecline}>
              <Text style={styles.buttonText}>Decline</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
    width: '90%',
    maxWidth: 400,
  },
  closeButton: {
    alignSelf: 'flex-end',
  },
  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  customerImageContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  customerImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  detailText: {
    fontSize: 16,
    marginVertical: 5,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
  },
  fareText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    width: '45%',
  },
  acceptButton: {
    backgroundColor: '#28a745',
  },
  declineButton: {
    backgroundColor: '#dc3545',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
});

export default TripRequestModal;
