const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const tripRoutes = require('./routes/trips');
const subscriptionRoutes = require('./routes/subscription');
const register = require('./routes/register');
const driverDocumentsRoute = require("./routes/getDriverDocuments");
const carListing = require("./routes/carListing");
const Login = require('./routes/Login');
const customerDetails = require('./routes/customerDetails');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json()); // Parse incoming JSON requests

// Create the HTTP server
const server = http.createServer(app);

// Initialize Socket.IO
const io = new Server(server, { 
    cors: { 
        origin: [`http://localhost:${port}`], 
        methods: ["POST", "GET", "PUT", "DELETE", "PATCH"] 
    } 
});

// Socket connection setup
// Socket connection setup
io.on('connection', (socket) => {
  console.log(`New client connected: ${socket.id}`);

  // Handle joining rooms (drivers & customers)
  socket.on('joinRoom', (userId) => {
      const roomName = `customer_${userId}`;
      socket.join(roomName);
      console.log(`User with ID ${userId} joined room: ${roomName}`);
  });

  // Emit when a trip is accepted
  socket.on('acceptTrip', (tripId) => {
      io.emit('tripAccepted', { tripId });
  });

  // Emit when a trip is cancelled
  socket.on('tripCancelled', (tripId) => {
      io.emit('tripCancelled', { tripId });
  });

  // Handle disconnection
  socket.on('disconnect', () => {
      console.log('Client disconnected');
  });

  socket.on('error', (error) => {
      console.error('Socket connection error:', error);
  });
});


// Attach io to the app (so it can be used in routes)
app.set('io', io);

// Routes
app.use("/api", tripRoutes);
app.use("/api", subscriptionRoutes);
app.use("/api", register);
app.use("/api", driverDocumentsRoute);
app.use("/api", carListing);
app.use("/api", Login);
app.use("/api", customerDetails);


// Start server
// server.listen(port, () => {
//     console.log(`Server running on http://localhost:${port}`);
// });

server.listen(port,"10.100.99.10")