const express = require('express');
const router = express.Router();  // Use `router` instead of `app`
const db = require('../config/config');
const firestoreDb = require('../config/FirebaseConfig').db;

// Handle trip creation
router.post('/trips', (req, res) => {
    console.log('Request Body:', req.body); // Log the incoming request body

    const {
        customerId, driverId, requestDate, currentDate, pickUpLocation, dropOffLocation, statuses,
        rating, feedback, duration_minutes, vehicle_type, distance_traveled, cancellation_reason,
        cancel_by, pickupTime, dropOffTime, pickUpCoordinates, dropOffCoordinates
    } = req.body;

    // Check for required fields
    if (!customerId || !driverId || !requestDate || !currentDate || !pickUpLocation || !dropOffLocation || !vehicle_type || !distance_traveled) {
        return res.status(400).json({ error: "Required fields are missing" });
    }

    // Prepare SQL query to insert trip data into MySQL
    const sql = `
        INSERT INTO trip (
            customerId, driverId, requestDate, currentDate, pickUpLocation, dropOffLocation, statuses,
            customer_rating, customer_feedback, duration_minutes, vehicle_type, distance_traveled, cancellation_reason,
            cancel_by, pickupTime, dropOffTime, pickUpCoordinates, dropOffCoordinates
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `; 

    // Convert coordinates to POINT format for MySQL
    const pickUpCoordinatesPoint = `POINT(${pickUpCoordinates.longitude} ${pickUpCoordinates.latitude})`;
    const dropOffCoordinatesPoint = `POINT(${dropOffCoordinates.longitude} ${dropOffCoordinates.latitude})`;

    // Execute the SQL query to insert into MySQL
    db.query(sql, [
        customerId, driverId, requestDate, currentDate, pickUpLocation, dropOffLocation, statuses,
        rating, feedback, duration_minutes, vehicle_type, distance_traveled, cancellation_reason,
        cancel_by, pickupTime, dropOffTime, pickUpCoordinatesPoint, dropOffCoordinatesPoint
    ], async (err, result) => {

        if (err) {
            console.error("Error saving trip data:", err);
            return res.status(500).json({ error: "An error occurred while saving trip data" });
        }
        
        const tripId = result.insertId; // Get the inserted trip ID
        if (!tripId) {
            console.error("Trip ID not generated after insertion");
            return res.status(500).json({ error: "Failed to generate trip ID after insertion" });
        }

        // Insert trip data into Firestore for real-time tracking
        try {
            const tripRef = firestoreDb.collection('trips').doc(`${tripId}`);
            await tripRef.set({
                customerId,
                driverId,
                requestDate,
                currentDate,
                pickUpLocation,
                dropOffLocation,
                statuses,
                rating,
                feedback,
                duration_minutes,
                vehicle_type,
                distance_traveled,
                cancellation_reason,
                cancel_by,
                pickupTime,
                dropOffTime,
                pickUpCoordinates: { latitude: pickUpCoordinates.latitude, longitude: pickUpCoordinates.longitude },
                dropOffCoordinates: { latitude: dropOffCoordinates.latitude, longitude: dropOffCoordinates.longitude },
            });
            console.log("Trip data saved to Firestore.");

            // Emit an event to notify drivers/customers
            const io = req.app.get('io');
            io.emit('newTrip', { tripId, customerId, driverId, pickUpLocation, dropOffLocation });

            return res.status(200).json({ message: "Trip data saved successfully", tripId: tripId });
        } catch (firestoreError) {
            console.error("Error saving trip data to Firestore:", firestoreError);
            return res.status(500).json({ error: "Error saving trip data to Firestore" });
        }
    });
});

// Fetch pending trips
router.get('/pending-trips', (req, res) => {
    // Query the database for pending trips, and join with users to fetch customer details
    const query = `
        SELECT 
            trips.*, 
            users.name AS customer_name, 
            users.email AS customer_email, 
            users.phoneNumber AS customer_phoneNumber, 
            users.address AS customer_address, 
            users.profile_picture AS customer_profile_picture 
        FROM 
            trips 
        JOIN  
            users ON trips.customerId = users.id 
        WHERE 
            trips.statuses = "pending"
    `;
     
    db.query(query, (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching trips' });
        }
        res.json(result); // Send the result as JSON
    });
});
// Update trip status when a driver accepts or declines
router.put('/trips/:id/status', (req, res) => {
    const { id } = req.params;
    const { status, cancellation_reason, cancel_by } = req.body;
  
    // Ensure only valid statuses are accepted
    const validStatuses = ['pending', 'completed', 'cancelled', 'accepted'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: "Invalid status value" });
    }
  
    // Prepare SQL query to update trip status and other details
    const sql = `
      UPDATE trips 
      SET statuses = ?, cancellation_reason = ?, cancel_by = ? 
      WHERE id = ?
    `;
  
    db.query(sql, [status, cancellation_reason, cancel_by, id], (err, result) => {
      if (err) {
        console.error("Error updating trip status:", err);
        return res.status(500).json({ error: "Error updating trip status" });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "Trip not found" });
      }
  
      // Emit event to notify users about the status change
      const io = req.app.get('io');
      io.emit('tripStatusUpdated', { tripId: id, status });
  
      res.status(200).json({ message: `Trip status updated to ${status}`, tripId: id });
    });
  });
  
  



module.exports = router;  // Make sure to export the router, not app

